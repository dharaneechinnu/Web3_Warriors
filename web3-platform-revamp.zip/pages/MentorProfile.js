"use client"

import { useState, useEffect } from "react"
import { useParams } from "react-router-dom"
import styled, { keyframes } from "styled-components"
import { motion } from "framer-motion"
import Web3 from "web3"
import api from "../services/api"
import Button from "../components/ui/Button"
import Card from "../components/ui/Card"
import Badge from "../components/ui/Badge"
import { Heading2, Heading3, Paragraph } from "../components/ui/Typography"

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`

const ProfileContainer = styled.div`
  padding: 2rem;
  margin-top: 4rem;
  max-width: 800px;
  margin-left: auto;
  margin-right: auto;
  
  @media (max-width: 768px) {
    padding: 1rem;
  }
`

const ProfileCard = styled(Card)`
  animation: ${fadeIn} 0.5s ease-out;
`

const ProfileHeader = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 2rem;
`

const ProfileAvatar = styled.div`
  width: 120px;
  height: 120px;
  border-radius: 50%;
  background: linear-gradient(135deg, #7c3aed, #4f46e5);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 3rem;
  font-weight: 700;
  color: white;
  margin-bottom: 1.5rem;
  border: 3px solid rgba(255, 255, 255, 0.2);
`

const ProfileInfo = styled.div`
  margin-bottom: 2rem;
`

const ProfileField = styled.div`
  margin-bottom: 1.5rem;
  
  label {
    display: block;
    font-size: 0.875rem;
    color: rgba(255, 255, 255, 0.6);
    margin-bottom: 0.25rem;
  }
  
  p {
    color: white;
    font-size: 1rem;
  }
`

const SkillsContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  margin-top: 0.5rem;
`

const Skill = styled(Badge)`
  margin-right: 0.5rem;
  margin-bottom: 0.5rem;
`

const ErrorMessage = styled.div`
  background: rgba(239, 68, 68, 0.2);
  color: #ef4444;
  padding: 1rem;
  border-radius: 0.5rem;
  margin-bottom: 1rem;
`

const SuccessMessage = styled.div`
  background: rgba(16, 185, 129, 0.2);
  color: #10b981;
  padding: 1rem;
  border-radius: 0.5rem;
  margin-bottom: 1rem;
`

const MentorProfile = () => {
  const { id } = useParams()
  const [profile, setProfile] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(null)

  useEffect(() => {
    fetchMentorProfile()
  }, [])

  const fetchMentorProfile = async () => {
    try {
      setLoading(true)
      setError(null)

      const response = await api.get(`mentorship/getMentor/${id}`)
      setProfile(response.data)
    } catch (err) {
      console.error("Error fetching mentor profile:", err)
      setError("Failed to load mentor profile")
    } finally {
      setLoading(false)
    }
  }

  const transferForMentorship = async () => {
    try {
      if (!window.ethereum) {
        alert("MetaMask is not installed!")
        return
      }

      const web3 = new Web3(window.ethereum)
      await window.ethereum.request({ method: "eth_requestAccounts" })
      const accounts = await web3.eth.getAccounts()
      const sender = accounts[0]

      const contractAddress = "YOUR_CONTRACT_ADDRESS"
      const contractABI = [
        {
          constant: false,
          inputs: [
            { name: "_to", type: "address" },
            { name: "_amount", type: "uint256" },
          ],
          name: "transferForMentorship",
          outputs: [],
          stateMutability: "nonpayable",
          type: "function",
        },
      ]

      const contract = new web3.eth.Contract(contractABI, contractAddress)
      const amountToSend = web3.utils.toWei("0.01", "ether")

      await contract.methods
        .transferForMentorship(profile.mentorship.walletAddress, amountToSend)
        .send({ from: sender })
      setSuccess("Transaction successful!")

      setTimeout(() => {
        setSuccess(null)
      }, 3000)
    } catch (err) {
      console.error("Transaction failed:", err)
      setError("Transaction failed. Please try again.")
    }
  }

  if (loading && !profile) {
    return (
      <ProfileContainer>
        <div className="flex items-center justify-center min-h-[50vh]">
          <div className="text-2xl text-white">Loading...</div>
        </div>
      </ProfileContainer>
    )
  }

  return (
    <ProfileContainer>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <ProfileCard>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "2rem" }}>
            <Heading2>Mentor Profile</Heading2>
            <Button onClick={transferForMentorship}>Pay for Mentorship</Button>
          </div>

          {error && <ErrorMessage>{error}</ErrorMessage>}
          {success && <SuccessMessage>{success}</SuccessMessage>}

          <ProfileHeader>
            <ProfileAvatar>
              {profile?.mentorship?.name ? profile.mentorship.name.charAt(0).toUpperCase() : "M"}
            </ProfileAvatar>
            <Heading3>{profile?.mentorship?.name}</Heading3>
          </ProfileHeader>

          <ProfileInfo>
            <ProfileField>
              <label>Skills</label>
              <SkillsContainer>
                {profile?.mentorship?.skills?.map((skill, index) => (
                  <Skill key={index} variant="primary">
                    {skill}
                  </Skill>
                )) || "No skills listed"}
              </SkillsContainer>
            </ProfileField>

            <ProfileField>
              <label>Wallet Address</label>
              <p>{profile?.mentorship?.walletAddress || "Not available"}</p>
            </ProfileField>

            <ProfileField>
              <label>Experience</label>
              <p>{profile?.mentorship?.experience || "Not specified"}</p>
            </ProfileField>

            <ProfileField>
              <label>About</label>
              <p>{profile?.mentorship?.about || "No information provided"}</p>
            </ProfileField>
          </ProfileInfo>

          <div style={{ marginTop: "2rem" }}>
            <Heading3>Mentorship Sessions</Heading3>
            <Paragraph>
              Book a mentorship session with {profile?.mentorship?.name} to get personalized guidance on your learning
              journey.
            </Paragraph>
            <Button style={{ marginTop: "1rem" }} onClick={transferForMentorship}>
              Book a Session
            </Button>
          </div>
        </ProfileCard>
      </motion.div>
    </ProfileContainer>
  )
}

export default MentorProfile

