"use client"

import { useState, useEffect } from "react"
import { useNavigate } from "react-router-dom"
import styled, { keyframes } from "styled-components"
import { motion } from "framer-motion"
import api from "../services/api"
import Button from "../components/ui/Button"
import Card from "../components/ui/Card"
import Badge from "../components/ui/Badge"
import { Heading2, Heading3, Paragraph } from "../components/ui/Typography"

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`

const DashboardContainer = styled.div`
  padding: 2rem;
  margin-top: 4rem;
  
  @media (max-width: 768px) {
    padding: 1rem;
  }
`

const TabsContainer = styled.div`
  display: flex;
  justify-content: center;
  gap: 1rem;
  margin-bottom: 2rem;
  flex-wrap: wrap;
  
  @media (max-width: 640px) {
    gap: 0.5rem;
  }
`

const TabButton = styled.button`
  padding: 0.75rem 1.5rem;
  background: ${(props) => (props.active ? "linear-gradient(135deg, #7c3aed, #4f46e5)" : "rgba(30, 30, 46, 0.6)")};
  color: white;
  border: none;
  border-radius: 0.5rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    transform: ${(props) => (props.active ? "none" : "translateY(-2px)")};
    background: ${(props) => (props.active ? "linear-gradient(135deg, #7c3aed, #4f46e5)" : "rgba(30, 30, 46, 0.8)")};
  }
  
  @media (max-width: 640px) {
    padding: 0.5rem 1rem;
    font-size: 0.875rem;
  }
`

const ContentContainer = styled(motion.div)`
  animation: ${fadeIn} 0.5s ease-out;
`

const CoursesGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 2rem;
  
  @media (max-width: 640px) {
    grid-template-columns: 1fr;
  }
`

const CourseCard = styled(Card)`
  display: flex;
  flex-direction: column;
  height: 100%;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-10px);
  }
`

const CourseImage = styled.div`
  height: 180px;
  border-radius: 0.5rem 0.5rem 0 0;
  overflow: hidden;
  position: relative;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.5s ease;
  }
  
  &:hover img {
    transform: scale(1.05);
  }
`

const CourseContent = styled.div`
  padding: 1.5rem;
  flex: 1;
  display: flex;
  flex-direction: column;
`

const CourseTitle = styled.h3`
  font-size: 1.25rem;
  font-weight: 600;
  margin-bottom: 0.5rem;
  color: white;
`

const CourseDescription = styled.p`
  color: rgba(255, 255, 255, 0.7);
  margin-bottom: 1.5rem;
  flex: 1;
  
  /* Limit to 3 lines */
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
`

const VideoContainer = styled.div`
  width: 100%;
  border-radius: 0.5rem;
  overflow: hidden;
  margin-bottom: 1rem;
  
  video {
    width: 100%;
    border-radius: 0.5rem;
  }
`

const ProfileContainer = styled.div`
  display: grid;
  grid-template-columns: 1fr 2fr;
  gap: 2rem;
  
  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
  }
`

const ProfileCard = styled(Card)`
  height: fit-content;
`

const ProfileAvatar = styled.div`
  width: 100px;
  height: 100px;
  border-radius: 50%;
  background: linear-gradient(135deg, #7c3aed, #4f46e5);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 2.5rem;
  font-weight: 700;
  color: white;
  margin: 0 auto 1.5rem;
  border: 3px solid rgba(255, 255, 255, 0.2);
`

const ProfileInfo = styled.div`
  margin-bottom: 2rem;
`

const ProfileField = styled.div`
  margin-bottom: 1rem;
  
  label {
    display: block;
    font-size: 0.875rem;
    color: rgba(255, 255, 255, 0.6);
    margin-bottom: 0.25rem;
  }
  
  p {
    color: white;
    font-size: 1rem;
  }
`

const SkillsContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  margin-top: 0.5rem;
`

const Skill = styled(Badge)`
  margin-right: 0.5rem;
  margin-bottom: 0.5rem;
`

const FormContainer = styled.div`
  background: rgba(30, 30, 46, 0.5);
  border-radius: 1rem;
  padding: 2rem;
  border: 1px solid rgba(124, 58, 237, 0.2);
`

const FormGroup = styled.div`
  margin-bottom: 1.5rem;
`

const FormLabel = styled.label`
  display: block;
  margin-bottom: 0.5rem;
  color: white;
`

const FormInput = styled.input`
  width: 100%;
  padding: 0.75rem 1rem;
  background: rgba(30, 30, 46, 0.6);
  border: 2px solid rgba(124, 58, 237, 0.3);
  border-radius: 0.5rem;
  color: white;
  
  &:focus {
    outline: none;
    border-color: #7c3aed;
  }
`

const FormTextarea = styled.textarea`
  width: 100%;
  padding: 0.75rem 1rem;
  background: rgba(30, 30, 46, 0.6);
  border: 2px solid rgba(124, 58, 237, 0.3);
  border-radius: 0.5rem;
  color: white;
  min-height: 100px;
  
  &:focus {
    outline: none;
    border-color: #7c3aed;
  }
`

const FormSelect = styled.select`
  width: 100%;
  padding: 0.75rem 1rem;
  background: rgba(30, 30, 46, 0.6);
  border: 2px solid rgba(124, 58, 237, 0.3);
  border-radius: 0.5rem;
  color: white;
  
  &:focus {
    outline: none;
    border-color: #7c3aed;
  }
  
  option {
    background: #1e1e2e;
  }
`

const FileInput = styled.div`
  position: relative;
  
  input[type="file"] {
    position: absolute;
    top: 0;
    left: 0;
    opacity: 0;
    width: 100%;
    height: 100%;
    cursor: pointer;
  }
  
  .file-label {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0.75rem 1rem;
    background: rgba(30, 30, 46, 0.6);
    border: 2px dashed rgba(124, 58, 237, 0.5);
    border-radius: 0.5rem;
    color: white;
    cursor: pointer;
    transition: all 0.3s ease;
  }
  
  &:hover .file-label {
    background: rgba(124, 58, 237, 0.1);
  }
  
  .file-name {
    margin-top: 0.5rem;
    font-size: 0.875rem;
    color: rgba(255, 255, 255, 0.7);
  }
`

const MentorsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 2rem;
  
  @media (max-width: 640px) {
    grid-template-columns: 1fr;
  }
`

const MentorCard = styled(Card)`
  display: flex;
  flex-direction: column;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-10px);
  }
`

const MentorAvatar = styled.div`
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: linear-gradient(135deg, #7c3aed, #4f46e5);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.75rem;
  font-weight: 700;
  color: white;
  margin: 0 auto 1rem;
  border: 3px solid rgba(255, 255, 255, 0.2);
`

const ErrorMessage = styled.div`
  background: rgba(239, 68, 68, 0.2);
  color: #ef4444;
  padding: 1rem;
  border-radius: 0.5rem;
  margin-bottom: 1rem;
`

const SuccessMessage = styled.div`
  background: rgba(16, 185, 129, 0.2);
  color: #10b981;
  padding: 1rem;
  border-radius: 0.5rem;
  margin-bottom: 1rem;
`

const Dashboard = () => {
  const navigate = useNavigate()
  const [userRole] = useState(localStorage.getItem("userRole") || "user")
  const [activeTab, setActiveTab] = useState("learner")
  const [courses, setCourses] = useState([])
  const [userProfile, setUserProfile] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(null)
  const [isEditing, setIsEditing] = useState(false)
  const [selectedCourse, setSelectedCourse] = useState(null)
  const [enrolledCourses, setEnrolledCourses] = useState([])
  const [mentors, setMentors] = useState([])
  const [editForm, setEditForm] = useState({
    name: "",
    mobileNo: "",
    UserWalletAddress: "",
    skills: [],
    gender: "",
    dob: "",
  })

  const [courseForm, setCourseForm] = useState({
    title: "",
    description: "",
    image: null,
    thumbnail: null,
    video: null,
  })

  const userId = localStorage.getItem("userId")

  useEffect(() => {
    fetchInitialData()
  }, [activeTab])

  const fetchInitialData = async () => {
    try {
      setLoading(true)
      setError(null)

      const token = localStorage.getItem("token")
      const headers = { Authorization: `Bearer ${token}` }

      switch (activeTab) {
        case "learner":
          const coursesRes = await api.get("/courses/getall", { headers })
          setCourses(coursesRes.data)
          break
        case "profile":
          const profileRes = await api.get(`/User/${userId}`)
          setUserProfile(profileRes.data)
          setEditForm({
            name: profileRes.data.name || "",
            email: profileRes.data.email || "",
            mobileNo: profileRes.data.mobileNo || "",
            UserWalletAddress: profileRes.data.UserWalletAddress || "",
            skills: profileRes.data.skills || [],
            gender: profileRes.data.gender || "",
            dob: profileRes.data.dob ? profileRes.data.dob.split("T")[0] : "",
          })
          break
        case "mentor":
          const mentorCoursesRes = await api.get(`/courses/mentor/${userId}`, { headers })
          setCourses(mentorCoursesRes.data.courses || [])
          break
        case "enrolled":
          const enrolledRes = await api.get(`/courses/enrolled/${userId}`, { headers })
          setEnrolledCourses(Array.isArray(enrolledRes.data) ? enrolledRes.data : [])
          break
        case "mentorship":
          const mentorsRes = await api.get("/mentorship/getallmentor")
          setMentors(Array.isArray(mentorsRes.data.mentorship) ? mentorsRes.data.mentorship : [])
          break
      }
    } catch (err) {
      console.error("Error fetching data:", err)
      setError("Failed to load data. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const handleEnrollCourse = async (courseId) => {
    try {
      await api.post("/courses/enroll", {
        learnerId: userId,
        courseId: courseId,
      })

      setSelectedCourse(courseId)
      setSuccess("Successfully enrolled in the course!")

      setTimeout(() => {
        setSuccess(null)
      }, 3000)
    } catch (err) {
      setError("Failed to enroll in course. Please try again.")
    }
  }

  const handleCourseComplete = async (courseId) => {
    try {
      const response = await api.post("/courses/complete", {
        learnerId: userId,
        courseId: courseId,
      })

      if (response.status === 200) {
        setSuccess("Course completed successfully!")
        setTimeout(() => {
          setSuccess(null)
        }, 3000)
      } else if (response.status === 400) {
        setError(response.message)
      }

      setSelectedCourse(null)
      fetchInitialData()
    } catch (error) {
      setError("Failed to mark course as complete. Please try again.")
    }
  }

  const handleCourseUpload = async (e) => {
    e.preventDefault()
    try {
      setLoading(true)
      setError(null)

      const token = localStorage.getItem("token")
      const formData = new FormData()

      formData.append("title", courseForm.title)
      formData.append("description", courseForm.description)
      formData.append("mentorId", userId)

      if (courseForm.image) {
        formData.append("image", courseForm.image)
      }

      if (courseForm.thumbnail) {
        formData.append("thumbnail", courseForm.thumbnail)
      }

      if (courseForm.video) {
        formData.append("video", courseForm.video)
      }

      await api.post("/courses/upload", formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "multipart/form-data",
        },
      })

      setCourseForm({
        title: "",
        description: "",
        image: null,
        thumbnail: null,
        video: null,
      })

      setSuccess("Course uploaded successfully!")
      setTimeout(() => {
        setSuccess(null)
      }, 3000)

      fetchInitialData()
    } catch (err) {
      setError("Failed to upload course. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const handleProfileUpdate = async (e) => {
    e.preventDefault()

    try {
      setLoading(true)
      setError(null)

      if (!userId) {
        setError("User ID is missing.")
        return
      }

      const response = await api.put(`/profile/${userId}`, editForm)

      if (response.status === 200) {
        setIsEditing(false)
        setSuccess("Profile updated successfully!")
        setTimeout(() => {
          setSuccess(null)
        }, 3000)
        fetchInitialData()
      }
    } catch (error) {
      console.error("Error updating profile:", error)
      setError("Failed to update profile. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const handleFileChange = (e, field) => {
    setCourseForm({
      ...courseForm,
      [field]: e.target.files[0],
    })
  }

  if (loading && !userProfile && !courses.length) {
    return (
      <DashboardContainer>
        <div className="flex items-center justify-center min-h-[50vh]">
          <div className="text-2xl text-white">Loading...</div>
        </div>
      </DashboardContainer>
    )
  }

  return (
    <DashboardContainer>
      <TabsContainer>
        <TabButton active={activeTab === "learner"} onClick={() => setActiveTab("learner")}>
          Learner
        </TabButton>
        <TabButton active={activeTab === "mentor"} onClick={() => setActiveTab("mentor")}>
          Mentor
        </TabButton>
        <TabButton active={activeTab === "mentorship"} onClick={() => setActiveTab("mentorship")}>
          Mentorship
        </TabButton>
        <TabButton active={activeTab === "enrolled"} onClick={() => setActiveTab("enrolled")}>
          Enrolled Courses
        </TabButton>
        <TabButton active={activeTab === "profile"} onClick={() => setActiveTab("profile")}>
          Profile
        </TabButton>
      </TabsContainer>

      {error && <ErrorMessage>{error}</ErrorMessage>}
      {success && <SuccessMessage>{success}</SuccessMessage>}

      <ContentContainer initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        {activeTab === "learner" && (
          <div>
            <Heading2>Available Courses</Heading2>
            <Paragraph>Explore our latest courses and start your learning journey today.</Paragraph>

            <CoursesGrid>
              {courses.map((course) => {
                const thumbnailPath = course.thumbnail
                  ? `http://localhost:3500/uploads/images/${course.thumbnail.split("\\").pop()}`
                  : "/placeholder.svg?height=180&width=320"
                const videoPath = course.video
                  ? `http://localhost:3500/uploads/videos/${course.video.split("\\").pop()}`
                  : ""

                return (
                  <CourseCard key={course._id}>
                    {selectedCourse === course._id ? (
                      <div>
                        <VideoContainer>
                          <video controls>
                            <source src={videoPath} type="video/mp4" />
                            Your browser does not support the video tag.
                          </video>
                        </VideoContainer>
                        <Button onClick={() => handleCourseComplete(course._id)} variant="primary">
                          Complete Course
                        </Button>
                      </div>
                    ) : (
                      <>
                        <CourseImage>
                          <img
                            src={thumbnailPath || "/placeholder.svg"}
                            onError={(e) => (e.target.src = "/placeholder.svg?height=180&width=320")}
                            alt={course.title}
                          />
                        </CourseImage>
                        <CourseContent>
                          <CourseTitle>{course.title}</CourseTitle>
                          <CourseDescription>{course.description}</CourseDescription>
                          <Button onClick={() => handleEnrollCourse(course._id)} variant="primary">
                            Start Learning
                          </Button>
                        </CourseContent>
                      </>
                    )}
                  </CourseCard>
                )
              })}
            </CoursesGrid>

            {courses.length === 0 && (
              <div className="text-center py-8">
                <Paragraph>No courses available at the moment.</Paragraph>
              </div>
            )}
          </div>
        )}

        {activeTab === "enrolled" && (
          <div>
            <Heading2>My Enrolled Courses</Heading2>
            <Paragraph>Continue learning from your enrolled courses.</Paragraph>

            <CoursesGrid>
              {enrolledCourses.map((course) => {
                const thumbnailPath = course.thumbnail
                  ? `http://localhost:3500/uploads/images/${course.thumbnail.split("\\").pop()}`
                  : "/placeholder.svg?height=180&width=320"
                const videoPath = course.video
                  ? `http://localhost:3500/uploads/videos/${course.video.split("\\").pop()}`
                  : ""

                return (
                  <CourseCard key={course._id}>
                    {selectedCourse === course._id ? (
                      <div>
                        <VideoContainer>
                          <video controls>
                            <source src={videoPath} type="video/mp4" />
                            Your browser does not support the video tag.
                          </video>
                        </VideoContainer>
                        <Button onClick={() => handleCourseComplete(course._id)} variant="primary">
                          Complete Course
                        </Button>
                      </div>
                    ) : (
                      <>
                        <CourseImage>
                          <img
                            src={thumbnailPath || "/placeholder.svg"}
                            onError={(e) => (e.target.src = "/placeholder.svg?height=180&width=320")}
                            alt={course.title}
                          />
                        </CourseImage>
                        <CourseContent>
                          <CourseTitle>{course.title}</CourseTitle>
                          <CourseDescription>{course.description}</CourseDescription>
                          <div className="flex justify-between items-center mb-4">
                            <span className="text-gray-400">Progress: {course.progress || 0}%</span>
                          </div>
                          <Button onClick={() => setSelectedCourse(course._id)} variant="primary">
                            Continue Learning
                          </Button>
                        </CourseContent>
                      </>
                    )}
                  </CourseCard>
                )
              })}
            </CoursesGrid>

            {enrolledCourses.length === 0 && (
              <div className="text-center py-8">
                <Paragraph>You haven't enrolled in any courses yet.</Paragraph>
                <Button onClick={() => setActiveTab("learner")} variant="secondary" style={{ marginTop: "1rem" }}>
                  Browse Courses
                </Button>
              </div>
            )}
          </div>
        )}

        {activeTab === "mentor" && (
          <div>
            <Heading2>Upload New Course</Heading2>
            <Paragraph>Share your knowledge by creating a new course.</Paragraph>

            <FormContainer>
              <form onSubmit={handleCourseUpload}>
                <FormGroup>
                  <FormLabel>Course Title</FormLabel>
                  <FormInput
                    type="text"
                    placeholder="Enter course title"
                    value={courseForm.title}
                    onChange={(e) => setCourseForm({ ...courseForm, title: e.target.value })}
                    required
                  />
                </FormGroup>

                <FormGroup>
                  <FormLabel>Course Description</FormLabel>
                  <FormTextarea
                    placeholder="Enter course description"
                    value={courseForm.description}
                    onChange={(e) => setCourseForm({ ...courseForm, description: e.target.value })}
                    required
                  />
                </FormGroup>

                <FormGroup>
                  <FormLabel>Course Image</FormLabel>
                  <FileInput>
                    <div className="file-label">{courseForm.image ? "Change Image" : "Upload Image"}</div>
                    <input type="file" accept="image/*" onChange={(e) => handleFileChange(e, "image")} />
                    {courseForm.image && <div className="file-name">{courseForm.image.name}</div>}
                  </FileInput>
                </FormGroup>

                <FormGroup>
                  <FormLabel>Course Thumbnail</FormLabel>
                  <FileInput>
                    <div className="file-label">{courseForm.thumbnail ? "Change Thumbnail" : "Upload Thumbnail"}</div>
                    <input type="file" accept="image/*" onChange={(e) => handleFileChange(e, "thumbnail")} />
                    {courseForm.thumbnail && <div className="file-name">{courseForm.thumbnail.name}</div>}
                  </FileInput>
                </FormGroup>

                <FormGroup>
                  <FormLabel>Course Video</FormLabel>
                  <FileInput>
                    <div className="file-label">{courseForm.video ? "Change Video" : "Upload Video"}</div>
                    <input type="file" accept="video/*" onChange={(e) => handleFileChange(e, "video")} />
                    {courseForm.video && <div className="file-name">{courseForm.video.name}</div>}
                  </FileInput>
                </FormGroup>

                <Button type="submit" disabled={loading}>
                  {loading ? "Uploading..." : "Upload Course"}
                </Button>
              </form>
            </FormContainer>

            <div style={{ marginTop: "3rem" }}>
              <Heading3>Your Courses</Heading3>
              <CoursesGrid>
                {courses.map((course) => {
                  const thumbnailPath = course.thumbnail
                    ? `http://localhost:3500/uploads/images/${course.thumbnail.split("\\").pop()}`
                    : "/placeholder.svg?height=180&width=320"

                  return (
                    <CourseCard key={course._id}>
                      <CourseImage>
                        <img
                          src={thumbnailPath || "/placeholder.svg"}
                          onError={(e) => (e.target.src = "/placeholder.svg?height=180&width=320")}
                          alt={course.title}
                        />
                      </CourseImage>
                      <CourseContent>
                        <CourseTitle>{course.title}</CourseTitle>
                        <CourseDescription>{course.description}</CourseDescription>
                        <div className="flex justify-between items-center">
                          <Badge variant="info">{course.enrollments || 0} Enrolled</Badge>
                        </div>
                      </CourseContent>
                    </CourseCard>
                  )
                })}
              </CoursesGrid>

              {courses.length === 0 && (
                <div className="text-center py-8">
                  <Paragraph>You haven't created any courses yet.</Paragraph>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === "profile" && userProfile && (
          <ProfileContainer>
            {isEditing ? (
              <FormContainer>
                <form onSubmit={handleProfileUpdate}>
                  <Heading3>Edit Profile</Heading3>

                  <FormGroup>
                    <FormLabel>Name</FormLabel>
                    <FormInput
                      type="text"
                      value={editForm.name}
                      onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                    />
                  </FormGroup>

                  <FormGroup>
                    <FormLabel>Mobile Number</FormLabel>
                    <FormInput
                      type="text"
                      value={editForm.mobileNo}
                      onChange={(e) => setEditForm({ ...editForm, mobileNo: e.target.value })}
                    />
                  </FormGroup>

                  <FormGroup>
                    <FormLabel>Wallet Address</FormLabel>
                    <FormInput
                      type="text"
                      value={editForm.UserWalletAddress}
                      onChange={(e) => setEditForm({ ...editForm, UserWalletAddress: e.target.value })}
                    />
                  </FormGroup>

                  <FormGroup>
                    <FormLabel>Gender</FormLabel>
                    <FormSelect
                      value={editForm.gender}
                      onChange={(e) => setEditForm({ ...editForm, gender: e.target.value })}
                    >
                      <option value="">Select Gender</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </FormSelect>
                  </FormGroup>

                  <FormGroup>
                    <FormLabel>Date of Birth</FormLabel>
                    <FormInput
                      type="date"
                      value={editForm.dob}
                      onChange={(e) => setEditForm({ ...editForm, dob: e.target.value })}
                    />
                  </FormGroup>

                  <FormGroup>
                    <FormLabel>Skills (comma-separated)</FormLabel>
                    <FormInput
                      type="text"
                      value={editForm.skills.join(", ")}
                      onChange={(e) =>
                        setEditForm({ ...editForm, skills: e.target.value.split(",").map((skill) => skill.trim()) })
                      }
                    />
                  </FormGroup>

                  <div className="flex gap-2">
                    <Button type="submit" disabled={loading}>
                      {loading ? "Saving..." : "Save Changes"}
                    </Button>
                    <Button type="button" variant="secondary" onClick={() => setIsEditing(false)}>
                      Cancel
                    </Button>
                  </div>
                </form>
              </FormContainer>
            ) : (
              <ProfileCard>
                <ProfileAvatar>{userProfile.name ? userProfile.name.charAt(0).toUpperCase() : "U"}</ProfileAvatar>

                <ProfileInfo>
                  <Heading3 style={{ textAlign: "center", marginBottom: "1.5rem" }}>
                    {userProfile.name || "User"}
                  </Heading3>

                  <ProfileField>
                    <label>Email</label>
                    <p>{userProfile.email || "N/A"}</p>
                  </ProfileField>

                  <ProfileField>
                    <label>Mobile Number</label>
                    <p>{userProfile.mobileNo || "N/A"}</p>
                  </ProfileField>

                  <ProfileField>
                    <label>Wallet Address</label>
                    <p>{userProfile.UserWalletAddress || "N/A"}</p>
                  </ProfileField>

                  <ProfileField>
                    <label>Gender</label>
                    <p>{userProfile.gender || "N/A"}</p>
                  </ProfileField>

                  <ProfileField>
                    <label>Date of Birth</label>
                    <p>{userProfile.dob ? new Date(userProfile.dob).toLocaleDateString() : "N/A"}</p>
                  </ProfileField>

                  <ProfileField>
                    <label>Tokens</label>
                    <p>{userProfile.tokens || 0}</p>
                  </ProfileField>

                  <ProfileField>
                    <label>Skills</label>
                    <SkillsContainer>
                      {userProfile.skills?.map((skill, index) => (
                        <Skill key={index} variant="primary">
                          {skill}
                        </Skill>
                      )) || "No skills added"}
                    </SkillsContainer>
                  </ProfileField>
                </ProfileInfo>

                <Button onClick={() => setIsEditing(true)}>Edit Profile</Button>
              </ProfileCard>
            )}

            <div>
              <Card>
                <Heading3>Account Statistics</Heading3>

                <div style={{ marginTop: "1.5rem" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "1rem" }}>
                    <span>Courses Completed</span>
                    <span>{userProfile.coursesCompleted?.length || 0}</span>
                  </div>

                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "1rem" }}>
                    <span>Courses Taught</span>
                    <span>{userProfile.coursesTaught?.length || 0}</span>
                  </div>

                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "1rem" }}>
                    <span>Courses In Progress</span>
                    <span>{enrolledCourses.length || 0}</span>
                  </div>

                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                    <span>Token Balance</span>
                    <span>{userProfile.tokens || 0}</span>
                  </div>
                </div>
              </Card>

              <Card style={{ marginTop: "2rem" }}>
                <Heading3>Recent Activity</Heading3>

                <div style={{ marginTop: "1.5rem" }}>
                  {/* This would be populated with actual activity data */}
                  <Paragraph>No recent activity to display.</Paragraph>
                </div>
              </Card>
            </div>
          </ProfileContainer>
        )}

        {activeTab === "mentorship" && (
          <div>
            <Heading2>Available Mentors</Heading2>
            <Paragraph>Connect with expert mentors to accelerate your learning journey.</Paragraph>

            <MentorsGrid>
              {mentors.map((mentor) => (
                <MentorCard key={mentor._id}>
                  <MentorAvatar>{mentor.name ? mentor.name.charAt(0).toUpperCase() : "M"}</MentorAvatar>

                  <Heading3 style={{ textAlign: "center", marginBottom: "1rem" }}>{mentor.name}</Heading3>

                  <Paragraph style={{ marginBottom: "1.5rem" }}>{mentor.email}</Paragraph>

                  {mentor.skills && mentor.skills.length > 0 && (
                    <div style={{ marginBottom: "1.5rem" }}>
                      <label style={{ display: "block", marginBottom: "0.5rem", fontWeight: "500" }}>Skills</label>
                      <SkillsContainer>
                        {mentor.skills.map((skill, index) => (
                          <Skill key={index} variant="primary">
                            {skill}
                          </Skill>
                        ))}
                      </SkillsContainer>
                    </div>
                  )}

                  <Button onClick={() => navigate(`/mentor/${mentor.mentorId}`)}>View Profile</Button>
                </MentorCard>
              ))}
            </MentorsGrid>

            {mentors.length === 0 && (
              <div className="text-center py-8">
                <Paragraph>No mentors available at the moment.</Paragraph>
              </div>
            )}
          </div>
        )}
      </ContentContainer>
    </DashboardContainer>
  )
}

export default Dashboard

