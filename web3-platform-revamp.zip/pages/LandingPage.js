"use client"

import { useEffect, useRef } from "react"
import styled, { keyframes } from "styled-components"
import { motion } from "framer-motion"
import Button from "../components/ui/Button"
import Container from "../components/ui/Container"
import { Heading1, Heading2, Heading3, Paragraph, GradientText } from "../components/ui/Typography"

// Animations
const float = keyframes`
  0% { transform: translateY(0px); }
  50% { transform: translateY(-20px); }
  100% { transform: translateY(0px); }
`

const pulse = keyframes`
  0% { transform: scale(1); }
  50% { transform: scale(1.05); }
  100% { transform: scale(1); }
`

const rotate = keyframes`
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
`

// Styled Components
const HeroSection = styled.section`
  min-height: 100vh;
  display: flex;
  align-items: center;
  position: relative;
  overflow: hidden;
  padding: 8rem 0 4rem;
  
  @media (max-width: 768px) {
    padding: 6rem 0 3rem;
  }
`

const HeroBackground = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: radial-gradient(circle at 50% 50%, rgba(124, 58, 237, 0.1), transparent 70%);
  z-index: -1;
`

const HeroGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 3rem;
  align-items: center;
  
  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
    text-align: center;
  }
`

const HeroContent = styled.div`
  @media (max-width: 1024px) {
    order: 2;
  }
`

const HeroButtons = styled.div`
  display: flex;
  gap: 1rem;
  margin-top: 2rem;
  
  @media (max-width: 1024px) {
    justify-content: center;
  }
  
  @media (max-width: 480px) {
    flex-direction: column;
    width: 100%;
    max-width: 300px;
    margin-left: auto;
    margin-right: auto;
  }
`

const HeroImageContainer = styled.div`
  position: relative;
  
  @media (max-width: 1024px) {
    order: 1;
    max-width: 500px;
    margin: 0 auto;
  }
`

const HeroImage = styled.div`
  position: relative;
  width: 100%;
  height: 500px;
  animation: ${float} 6s ease-in-out infinite;
  
  @media (max-width: 768px) {
    height: 350px;
  }
`

const FloatingElement = styled.div`
  position: absolute;
  width: ${(props) => props.size || "60px"};
  height: ${(props) => props.size || "60px"};
  border-radius: ${(props) => (props.shape === "circle" ? "50%" : "12px")};
  background: ${(props) => props.bg || "linear-gradient(135deg, #7c3aed, #4f46e5)"};
  opacity: ${(props) => props.opacity || "0.7"};
  animation: ${float} ${(props) => props.duration || "6s"} ease-in-out infinite;
  animation-delay: ${(props) => props.delay || "0s"};
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
  
  &:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    border-radius: inherit;
    background: inherit;
    filter: blur(10px);
    opacity: 0.5;
    z-index: -1;
  }
`

const RotatingCircle = styled.div`
  position: absolute;
  width: 200px;
  height: 200px;
  border: 2px dashed rgba(124, 58, 237, 0.3);
  border-radius: 50%;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  animation: ${rotate} 20s linear infinite;
`

const FeatureSection = styled.section`
  padding: 6rem 0;
  position: relative;
  overflow: hidden;
  
  @media (max-width: 768px) {
    padding: 4rem 0;
  }
`

const SectionHeader = styled.div`
  text-align: center;
  max-width: 800px;
  margin: 0 auto 4rem;
`

const FeatureGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 2rem;
  
  @media (max-width: 1024px) {
    grid-template-columns: repeat(2, 1fr);
  }
  
  @media (max-width: 640px) {
    grid-template-columns: 1fr;
  }
`

const FeatureCard = styled.div`
  background: rgba(30, 30, 46, 0.5);
  border-radius: 1rem;
  padding: 2rem;
  transition: all 0.3s ease;
  border: 1px solid rgba(124, 58, 237, 0.2);
  position: relative;
  overflow: hidden;
  
  &:hover {
    transform: translateY(-10px);
    border-color: rgba(124, 58, 237, 0.5);
    box-shadow: 0 20px 30px -10px rgba(0, 0, 0, 0.3);
  }
  
  &:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 4px;
    height: 100%;
    background: linear-gradient(to bottom, #7c3aed, #4f46e5);
  }
`

const FeatureIcon = styled.div`
  width: 60px;
  height: 60px;
  border-radius: 12px;
  background: linear-gradient(135deg, #7c3aed, #4f46e5);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 1.5rem;
  color: white;
  font-size: 1.5rem;
  box-shadow: 0 10px 20px rgba(124, 58, 237, 0.3);
`

const HowItWorksSection = styled.section`
  padding: 6rem 0;
  background: rgba(20, 20, 30, 0.3);
  position: relative;
  
  @media (max-width: 768px) {
    padding: 4rem 0;
  }
`

const StepsContainer = styled.div`
  max-width: 800px;
  margin: 0 auto;
`

const Step = styled.div`
  display: flex;
  gap: 2rem;
  margin-bottom: 3rem;
  position: relative;
  
  @media (max-width: 640px) {
    flex-direction: column;
    gap: 1rem;
  }
  
  &:last-child {
    margin-bottom: 0;
  }
  
  &:not(:last-child):after {
    content: '';
    position: absolute;
    top: 4rem;
    left: 2rem;
    bottom: -3rem;
    width: 2px;
    background: linear-gradient(to bottom, #7c3aed, rgba(124, 58, 237, 0.1));
    
    @media (max-width: 640px) {
      left: 2rem;
    }
  }
`

const StepNumber = styled.div`
  width: 4rem;
  height: 4rem;
  border-radius: 50%;
  background: linear-gradient(135deg, #7c3aed, #4f46e5);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.5rem;
  font-weight: 700;
  color: white;
  flex-shrink: 0;
  box-shadow: 0 10px 20px rgba(124, 58, 237, 0.3);
`

const StepContent = styled.div`
  flex: 1;
`

const CTASection = styled.section`
  padding: 6rem 0;
  position: relative;
  overflow: hidden;
  
  @media (max-width: 768px) {
    padding: 4rem 0;
  }
`

const CTACard = styled.div`
  background: linear-gradient(135deg, rgba(124, 58, 237, 0.2), rgba(79, 70, 229, 0.2));
  border-radius: 1.5rem;
  padding: 4rem;
  text-align: center;
  position: relative;
  border: 1px solid rgba(124, 58, 237, 0.3);
  overflow: hidden;
  
  @media (max-width: 768px) {
    padding: 3rem 2rem;
  }
  
  &:before {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(124, 58, 237, 0.1), transparent 70%);
    z-index: -1;
  }
`

const CTAButtons = styled.div`
  display: flex;
  gap: 1rem;
  justify-content: center;
  margin-top: 2rem;
  
  @media (max-width: 480px) {
    flex-direction: column;
    max-width: 300px;
    margin-left: auto;
    margin-right: auto;
  }
`

const LandingPage = () => {
  const canvasRef = useRef(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    const particles = []

    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    class Particle {
      constructor() {
        this.x = Math.random() * canvas.width
        this.y = Math.random() * canvas.height
        this.size = Math.random() * 3 + 1
        this.speedX = Math.random() * 1 - 0.5
        this.speedY = Math.random() * 1 - 0.5
        this.color = `rgba(124, 58, 237, ${Math.random() * 0.3 + 0.1})`
      }

      update() {
        this.x += this.speedX
        this.y += this.speedY

        if (this.x < 0 || this.x > canvas.width) {
          this.speedX = -this.speedX
        }

        if (this.y < 0 || this.y > canvas.height) {
          this.speedY = -this.speedY
        }
      }

      draw() {
        ctx.fillStyle = this.color
        ctx.beginPath()
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2)
        ctx.fill()
      }
    }

    const init = () => {
      for (let i = 0; i < 100; i++) {
        particles.push(new Particle())
      }
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      for (let i = 0; i < particles.length; i++) {
        particles[i].update()
        particles[i].draw()
      }

      requestAnimationFrame(animate)
    }

    init()
    animate()

    const handleResize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [])

  return (
    <div>
      <canvas
        ref={canvasRef}
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          zIndex: -1,
        }}
      />

      <HeroSection>
        <HeroBackground />
        <Container>
          <HeroGrid>
            <HeroContent>
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
                <Heading1>
                  Learn <GradientText>Web3</GradientText> from the Best
                </Heading1>
                <Paragraph>
                  Connect with expert mentors, join live sessions, and master blockchain technology through hands-on
                  learning experiences. Our platform provides the tools and community you need to succeed in the
                  decentralized future.
                </Paragraph>
                <HeroButtons>
                  <Button size="large" pulse onClick={() => (window.location.href = "/register")}>
                    Get Started
                  </Button>
                  <Button size="large" variant="secondary" onClick={() => (window.location.href = "/login")}>
                    Login
                  </Button>
                </HeroButtons>
              </motion.div>
            </HeroContent>

            <HeroImageContainer>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.8, delay: 0.3 }}>
                <HeroImage>
                  <RotatingCircle />
                  <FloatingElement size="100px" style={{ top: "10%", left: "20%" }} delay="0.5s" />
                  <FloatingElement
                    size="70px"
                    shape="circle"
                    style={{ top: "60%", left: "10%" }}
                    delay="1s"
                    bg="linear-gradient(135deg, #4f46e5, #2563eb)"
                  />
                  <FloatingElement
                    size="120px"
                    style={{ top: "30%", right: "10%" }}
                    delay="1.5s"
                    bg="linear-gradient(135deg, #7c3aed, #8b5cf6)"
                  />
                  <FloatingElement
                    size="50px"
                    shape="circle"
                    style={{ bottom: "20%", right: "20%" }}
                    delay="2s"
                    bg="linear-gradient(135deg, #6366f1, #4f46e5)"
                  />
                </HeroImage>
              </motion.div>
            </HeroImageContainer>
          </HeroGrid>
        </Container>
      </HeroSection>

      <FeatureSection>
        <Container>
          <SectionHeader>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <Heading2>Why Choose Web3Warriors?</Heading2>
              <Paragraph>
                Our platform offers unique features designed to accelerate your blockchain learning journey and connect
                you with the best mentors in the industry.
              </Paragraph>
            </motion.div>
          </SectionHeader>

          <FeatureGrid>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <FeatureCard>
                <FeatureIcon>👨‍🏫</FeatureIcon>
                <Heading3>Expert Mentors</Heading3>
                <Paragraph>
                  Learn from experienced blockchain developers and industry experts who will guide you through your Web3
                  journey.
                </Paragraph>
              </FeatureCard>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <FeatureCard>
                <FeatureIcon>🔴</FeatureIcon>
                <Heading3>Live Sessions</Heading3>
                <Paragraph>
                  Join interactive live sessions where you can ask questions and get real-time feedback from mentors.
                </Paragraph>
              </FeatureCard>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <FeatureCard>
                <FeatureIcon>🪙</FeatureIcon>
                <Heading3>Token Economy</Heading3>
                <Paragraph>
                  Use platform tokens to book sessions, reward mentors, and participate in the Web3 Warriors ecosystem.
                </Paragraph>
              </FeatureCard>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <FeatureCard>
                <FeatureIcon>🧠</FeatureIcon>
                <Heading3>Hands-on Learning</Heading3>
                <Paragraph>
                  Practice what you learn with interactive coding exercises and real-world projects that build your
                  portfolio.
                </Paragraph>
              </FeatureCard>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.5 }}
            >
              <FeatureCard>
                <FeatureIcon>👥</FeatureIcon>
                <Heading3>Community</Heading3>
                <Paragraph>
                  Connect with like-minded learners, share knowledge, and collaborate on projects in our vibrant
                  community.
                </Paragraph>
              </FeatureCard>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.6 }}
            >
              <FeatureCard>
                <FeatureIcon>📱</FeatureIcon>
                <Heading3>Learn Anywhere</Heading3>
                <Paragraph>
                  Access our platform from any device, anytime. Your learning journey continues wherever you go.
                </Paragraph>
              </FeatureCard>
            </motion.div>
          </FeatureGrid>
        </Container>
      </FeatureSection>

      <HowItWorksSection>
        <Container>
          <SectionHeader>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <Heading2>How It Works</Heading2>
              <Paragraph>
                Getting started with Web3Warriors is easy. Follow these simple steps to begin your blockchain learning
                journey.
              </Paragraph>
            </motion.div>
          </SectionHeader>

          <StepsContainer>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <Step>
                <StepNumber>1</StepNumber>
                <StepContent>
                  <Heading3>Create an Account</Heading3>
                  <Paragraph>
                    Sign up and complete your profile to join the Web3 Warriors community. Connect your wallet to access
                    all platform features.
                  </Paragraph>
                </StepContent>
              </Step>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Step>
                <StepNumber>2</StepNumber>
                <StepContent>
                  <Heading3>Browse Sessions</Heading3>
                  <Paragraph>
                    Explore available live sessions and courses. Choose the ones that match your learning goals and
                    interests.
                  </Paragraph>
                </StepContent>
              </Step>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <Step>
                <StepNumber>3</StepNumber>
                <StepContent>
                  <Heading3>Book and Learn</Heading3>
                  <Paragraph>
                    Use your tokens to book sessions and start learning from expert mentors. Participate in interactive
                    lessons and hands-on projects.
                  </Paragraph>
                </StepContent>
              </Step>
            </motion.div>
          </StepsContainer>
        </Container>
      </HowItWorksSection>

      <CTASection>
        <Container>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <CTACard>
              <Heading2>Ready to Start Your Web3 Journey?</Heading2>
              <Paragraph>
                Join Web3Warriors today and take the first step towards mastering blockchain technology with expert
                guidance. Our community is waiting for you!
              </Paragraph>
              <CTAButtons>
                <Button size="large" pulse onClick={() => (window.location.href = "/register")}>
                  Join Now
                </Button>
                <Button size="large" variant="secondary" onClick={() => (window.location.href = "/login")}>
                  Learn More
                </Button>
              </CTAButtons>
            </CTACard>
          </motion.div>
        </Container>
      </CTASection>
    </div>
  )
}

export default LandingPage

