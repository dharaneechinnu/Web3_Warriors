"use client"

import { useState, useEffect } from "react"
import styled, { keyframes } from "styled-components"
import { motion } from "framer-motion"
import api from "../services/api"
import Button from "../components/ui/Button"
import Card from "../components/ui/Card"
import Input from "../components/ui/Input"
import Badge from "../components/ui/Badge"
import { Heading2, Heading3, Paragraph } from "../components/ui/Typography"

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`

const SessionsContainer = styled.div`
  padding: 2rem;
  margin-top: 4rem;
  
  @media (max-width: 768px) {
    padding: 1rem;
  }
`

const FiltersContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
  margin-bottom: 2rem;
  justify-content: space-between;
  align-items: center;
  
  @media (max-width: 768px) {
    flex-direction: column;
    align-items: stretch;
  }
`

const SearchContainer = styled.div`
  flex: 1;
  max-width: 400px;
  
  @media (max-width: 768px) {
    max-width: 100%;
  }
`

const FilterButtons = styled.div`
  display: flex;
  gap: 0.5rem;
  
  @media (max-width: 768px) {
    width: 100%;
    justify-content: space-between;
  }
`

const FilterButton = styled.button`
  padding: 0.5rem 1rem;
  background: ${(props) => (props.active ? "linear-gradient(135deg, #7c3aed, #4f46e5)" : "rgba(30, 30, 46, 0.6)")};
  color: white;
  border: none;
  border-radius: 0.5rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background: ${(props) => (props.active ? "linear-gradient(135deg, #7c3aed, #4f46e5)" : "rgba(30, 30, 46, 0.8)")};
  }
`

const SessionsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
  gap: 2rem;
  
  @media (max-width: 640px) {
    grid-template-columns: 1fr;
  }
`

const SessionCard = styled(Card)`
  animation: ${fadeIn} 0.5s ease-out;
  display: flex;
  flex-direction: column;
  height: 100%;
`

const SessionContent = styled.div`
  flex: 1;
`

const SessionDetails = styled.div`
  margin: 1.5rem 0;
`

const SessionDetail = styled.div`
  display: flex;
  margin-bottom: 0.75rem;
  
  label {
    font-weight: 500;
    width: 80px;
    color: rgba(255, 255, 255, 0.7);
  }
  
  span {
    color: white;
  }
`

const ErrorMessage = styled.div`
  background: rgba(239, 68, 68, 0.2);
  color: #ef4444;
  padding: 1rem;
  border-radius: 0.5rem;
  margin-bottom: 1rem;
`

const SuccessMessage = styled.div`
  background: rgba(16, 185, 129, 0.2);
  color: #10b981;
  padding: 1rem;
  border-radius: 0.5rem;
  margin-bottom: 1rem;
`

const EmptyState = styled.div`
  text-align: center;
  padding: 3rem 0;
  color: rgba(255, 255, 255, 0.7);
`

const LiveSessions = () => {
  const [sessions, setSessions] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [filter, setFilter] = useState("all") // all, upcoming, past

  useEffect(() => {
    fetchSessions()
  }, [])

  const fetchSessions = async () => {
    try {
      setLoading(true)
      setError(null)

      const token = localStorage.getItem("token")
      const response = await api.get("/sessions/getall", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      setSessions(response.data)
    } catch (err) {
      console.error("Error fetching sessions:", err)
      setError("Failed to load sessions")
    } finally {
      setLoading(false)
    }
  }

  const handleEnroll = async (sessionId) => {
    try {
      setError(null)
      setSuccess(null)

      const token = localStorage.getItem("token")
      const userId = localStorage.getItem("userId")

      await api.post(
        `/sessions/enroll`,
        {
          userId,
          sessionId,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      )

      setSuccess("Successfully enrolled in session!")

      // Refresh sessions list
      fetchSessions()

      setTimeout(() => {
        setSuccess(null)
      }, 3000)
    } catch (err) {
      console.error("Enrollment error:", err)
      setError(err.response?.data?.message || "Failed to enroll in session")
    }
  }

  const filterSessions = () => {
    let filtered = [...sessions]

    // Apply search filter
    if (searchQuery) {
      filtered = filtered.filter(
        (session) =>
          session.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          session.description.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    }

    // Apply time filter
    const now = new Date()
    if (filter === "upcoming") {
      filtered = filtered.filter((session) => new Date(session.startTime) > now)
    } else if (filter === "past") {
      filtered = filtered.filter((session) => new Date(session.startTime) < now)
    }

    return filtered
  }

  if (loading) {
    return (
      <SessionsContainer>
        <div className="flex items-center justify-center min-h-[50vh]">
          <div className="text-2xl text-white">Loading...</div>
        </div>
      </SessionsContainer>
    )
  }

  return (
    <SessionsContainer>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <Heading2>Live Sessions</Heading2>
        <Paragraph>Join interactive live sessions with expert mentors.</Paragraph>

        <FiltersContainer>
          <SearchContainer>
            <Input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search sessions..."
            />
          </SearchContainer>

          <FilterButtons>
            <FilterButton active={filter === "all"} onClick={() => setFilter("all")}>
              All
            </FilterButton>
            <FilterButton active={filter === "upcoming"} onClick={() => setFilter("upcoming")}>
              Upcoming
            </FilterButton>
            <FilterButton active={filter === "past"} onClick={() => setFilter("past")}>
              Past
            </FilterButton>
          </FilterButtons>
        </FiltersContainer>

        {error && <ErrorMessage>{error}</ErrorMessage>}
        {success && <SuccessMessage>{success}</SuccessMessage>}

        <SessionsGrid>
          {filterSessions().map((session) => {
            const isUpcoming = new Date(session.startTime) > new Date()

            return (
              <SessionCard key={session._id}>
                <SessionContent>
                  <Badge variant={isUpcoming ? "primary" : "info"}>{isUpcoming ? "Upcoming" : "Past"}</Badge>

                  <Heading3 style={{ marginTop: "1rem" }}>{session.title}</Heading3>
                  <Paragraph>{session.description}</Paragraph>

                  <SessionDetails>
                    <SessionDetail>
                      <label>Mentor:</label>
                      <span>{session.mentor.name}</span>
                    </SessionDetail>

                    <SessionDetail>
                      <label>Date:</label>
                      <span>{new Date(session.startTime).toLocaleDateString()}</span>
                    </SessionDetail>

                    <SessionDetail>
                      <label>Time:</label>
                      <span>{new Date(session.startTime).toLocaleTimeString()}</span>
                    </SessionDetail>

                    <SessionDetail>
                      <label>Duration:</label>
                      <span>{session.duration} minutes</span>
                    </SessionDetail>

                    <SessionDetail>
                      <label>Price:</label>
                      <span>{session.price} tokens</span>
                    </SessionDetail>
                  </SessionDetails>
                </SessionContent>

                {isUpcoming && !session.enrolled && (
                  <Button onClick={() => handleEnroll(session._id)}>Enroll Now</Button>
                )}

                {session.enrolled && (
                  <div
                    style={{
                      textAlign: "center",
                      padding: "0.75rem",
                      color: "#10b981",
                      fontWeight: "500",
                    }}
                  >
                    ✓ Enrolled
                  </div>
                )}

                {!isUpcoming && (
                  <div
                    style={{
                      textAlign: "center",
                      padding: "0.75rem",
                      color: "rgba(255, 255, 255, 0.6)",
                      fontWeight: "500",
                    }}
                  >
                    Session Ended
                  </div>
                )}
              </SessionCard>
            )
          })}
        </SessionsGrid>

        {filterSessions().length === 0 && (
          <EmptyState>
            <Paragraph>No sessions found</Paragraph>
          </EmptyState>
        )}
      </motion.div>
    </SessionsContainer>
  )
}

export default LiveSessions

