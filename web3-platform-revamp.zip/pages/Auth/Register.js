"use client"

import { useState } from "react"
import { useNavigate, Link } from "react-router-dom"
import styled, { keyframes } from "styled-components"
import { motion } from "framer-motion"
import axios from "axios"
import Web3 from "web3"
import { address } from "../../services/contractAddress"
import { contractabi } from "../../services/abi"
import Button from "../../components/ui/Button"
import Input from "../../components/ui/Input"
import { Heading2, Paragraph } from "../../components/ui/Typography"

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`

const RegisterContainer = styled.div`
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  position: relative;
  overflow: hidden;
`

const RegisterBackground = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: radial-gradient(circle at 70% 50%, rgba(124, 58, 237, 0.1), transparent 70%);
  z-index: -1;
`

const RegisterCard = styled.div`
  width: 100%;
  max-width: 500px;
  background: rgba(30, 30, 46, 0.7);
  backdrop-filter: blur(10px);
  border-radius: 1.5rem;
  padding: 3rem;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
  border: 1px solid rgba(124, 58, 237, 0.2);
  animation: ${fadeIn} 0.6s ease-out;
  position: relative;
  overflow: hidden;
  
  &:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: linear-gradient(90deg, #7c3aed, #4f46e5, #7c3aed);
  }
  
  @media (max-width: 480px) {
    padding: 2rem;
  }
`

const RegisterHeader = styled.div`
  text-align: center;
  margin-bottom: 2rem;
`

const RegisterForm = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`

const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`

const FormRow = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  
  @media (max-width: 480px) {
    grid-template-columns: 1fr;
  }
`

const RegisterButton = styled(Button)`
  margin-top: 1rem;
  width: 100%;
`

const RegisterFooter = styled.div`
  text-align: center;
  margin-top: 2rem;
`

const LoginLink = styled(Link)`
  color: #7c3aed;
  text-decoration: none;
  font-weight: 500;
  transition: all 0.2s ease;
  
  &:hover {
    color: #6d28d9;
    text-decoration: underline;
  }
`

const ErrorMessage = styled(motion.div)`
  background: rgba(239, 68, 68, 0.2);
  color: #ef4444;
  padding: 1rem;
  border-radius: 0.5rem;
  margin-bottom: 1rem;
  font-size: 0.875rem;
`

const Select = styled.select`
  width: 100%;
  padding: 0.75rem 1rem;
  font-size: 1rem;
  background: rgba(30, 30, 46, 0.6);
  border: 2px solid rgba(124, 58, 237, 0.3);
  border-radius: 0.5rem;
  color: white;30,46,0.6);
  border: 2px solid rgba(124, 58, 237, 0.3);
  border-radius: 0.5rem;
  color: white;
  transition: all 0.3s ease;
  
  &:focus {
    outline: none;
    border-color: #7c3aed;
    box-shadow: 0 0 0 3px rgba(124, 58, 237, 0.3);
  }
  
  &::placeholder {
    color: rgba(255, 255, 255, 0.5);
  }
  
  option {
    background: #1e1e2e;
  }
`

const Register = () => {
  const navigate = useNavigate()
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    dob: "",
    gender: "",
    mobileNo: "",
  })
  const [error, setError] = useState(null)
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      setError(null)
      setLoading(true)

      // Register user on backend
      const response = await axios.post("http://localhost:3500/Auth/register", formData)

      if (response.status === 200) {
        // Call blockchain function after successful registration
        await registerUserOnBlockchain(formData)

        // Navigate to login page with success message
        navigate("/login", { state: { message: "Registration successful! Please login." } })
      }
    } catch (err) {
      console.error("Registration error:", err)
      setError(err.response?.data?.message || "Registration failed")
    } finally {
      setLoading(false)
    }
  }

  const registerUserOnBlockchain = async (userData) => {
    try {
      // Connect to Ethereum using MetaMask
      if (window.ethereum) {
        const web3 = new Web3(window.ethereum)
        await window.ethereum.request({ method: "eth_requestAccounts" })

        const contractAddress = address // Replace with your contract address
        const contract = new web3.eth.Contract(contractabi, contractAddress)

        const accounts = await web3.eth.getAccounts()
        const userAccount = accounts[0]

        // Call the registerUser function of your contract
        const tx = await contract.methods
          .registerUser(
            userData.name,
            userData.email,
            userData.password,
            userData.dob,
            userData.gender,
            userData.mobileNo,
          )
          .send({ from: userAccount })

        console.log("Transaction hash:", tx.transactionHash)
      } else {
        alert("Please install MetaMask to continue.")
      }
    } catch (error) {
      console.error("Error registering user on blockchain:", error)
      alert("Blockchain registration failed.")
    }
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  return (
    <RegisterContainer>
      <RegisterBackground />
      <RegisterCard>
        <RegisterHeader>
          <Heading2>Create Account</Heading2>
          <Paragraph>Join the Web3Warriors community today</Paragraph>
        </RegisterHeader>

        {error && (
          <ErrorMessage initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
            {error}
          </ErrorMessage>
        )}

        <RegisterForm onSubmit={handleSubmit}>
          <FormGroup>
            <Input
              type="text"
              name="name"
              label="Full Name"
              placeholder="Enter your full name"
              value={formData.name}
              onChange={handleInputChange}
              required
            />
          </FormGroup>

          <FormGroup>
            <Input
              type="email"
              name="email"
              label="Email"
              placeholder="Enter your email"
              value={formData.email}
              onChange={handleInputChange}
              required
            />
          </FormGroup>

          <FormGroup>
            <Input
              type="password"
              name="password"
              label="Password"
              placeholder="Create a password"
              value={formData.password}
              onChange={handleInputChange}
              required
            />
          </FormGroup>

          <FormRow>
            <FormGroup>
              <label htmlFor="dob">Date of Birth</label>
              <Input type="date" id="dob" name="dob" value={formData.dob} onChange={handleInputChange} required />
            </FormGroup>

            <FormGroup>
              <label htmlFor="gender">Gender</label>
              <Select id="gender" name="gender" value={formData.gender} onChange={handleInputChange} required>
                <option value="">Select gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </Select>
            </FormGroup>
          </FormRow>

          <FormGroup>
            <Input
              type="tel"
              name="mobileNo"
              label="Mobile Number"
              placeholder="Enter your mobile number"
              value={formData.mobileNo}
              onChange={handleInputChange}
              required
            />
          </FormGroup>

          <RegisterButton type="submit" disabled={loading}>
            {loading ? "Creating Account..." : "Create Account"}
          </RegisterButton>
        </RegisterForm>

        <RegisterFooter>
          <Paragraph>
            Already have an account? <LoginLink to="/login">Login here</LoginLink>
          </Paragraph>
        </RegisterFooter>
      </RegisterCard>
    </RegisterContainer>
  )
}

export default Register

