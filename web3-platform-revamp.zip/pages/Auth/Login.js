"use client"

import { useState } from "react"
import { useNavigate, Link } from "react-router-dom"
import styled, { keyframes } from "styled-components"
import { motion } from "framer-motion"
import axios from "axios"
import Button from "../../components/ui/Button"
import Input from "../../components/ui/Input"
import { Heading2, Paragraph } from "../../components/ui/Typography"

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`

const LoginContainer = styled.div`
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  position: relative;
  overflow: hidden;
`

const LoginBackground = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: radial-gradient(circle at 30% 50%, rgba(124, 58, 237, 0.1), transparent 70%);
  z-index: -1;
`

const LoginCard = styled.div`
  width: 100%;
  max-width: 450px;
  background: rgba(30, 30, 46, 0.7);
  backdrop-filter: blur(10px);
  border-radius: 1.5rem;
  padding: 3rem;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
  border: 1px solid rgba(124, 58, 237, 0.2);
  animation: ${fadeIn} 0.6s ease-out;
  position: relative;
  overflow: hidden;
  
  &:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: linear-gradient(90deg, #7c3aed, #4f46e5, #7c3aed);
  }
  
  @media (max-width: 480px) {
    padding: 2rem;
  }
`

const LoginHeader = styled.div`
  text-align: center;
  margin-bottom: 2rem;
`

const LoginForm = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`

const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`

const ForgotPassword = styled(Link)`
  align-self: flex-end;
  font-size: 0.875rem;
  color: #7c3aed;
  text-decoration: none;
  transition: all 0.2s ease;
  
  &:hover {
    color: #6d28d9;
    text-decoration: underline;
  }
`

const LoginButton = styled(Button)`
  margin-top: 1rem;
  width: 100%;
`

const LoginFooter = styled.div`
  text-align: center;
  margin-top: 2rem;
`

const RegisterLink = styled(Link)`
  color: #7c3aed;
  text-decoration: none;
  font-weight: 500;
  transition: all 0.2s ease;
  
  &:hover {
    color: #6d28d9;
    text-decoration: underline;
  }
`

const ErrorMessage = styled(motion.div)`
  background: rgba(239, 68, 68, 0.2);
  color: #ef4444;
  padding: 1rem;
  border-radius: 0.5rem;
  margin-bottom: 1rem;
  font-size: 0.875rem;
`

const Login = () => {
  const navigate = useNavigate()
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  })
  const [error, setError] = useState(null)
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      setError(null)
      setLoading(true)

      const response = await axios.post("http://localhost:3500/Auth/login", formData)
      console.log(response.data)

      if (response.data) {
        localStorage.setItem("token", response.data.accessToken)
        localStorage.setItem("userRole", response.data.user.role || "user")
        localStorage.setItem("userId", response.data.user._id)
        localStorage.setItem("tokencoin", response.data.user.tokenBalance)
        navigate("/dashboard")
      }
    } catch (err) {
      console.error("Login error:", err)
      setError(err.response?.data?.message || "Invalid email or password")
    } finally {
      setLoading(false)
    }
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  return (
    <LoginContainer>
      <LoginBackground />
      <LoginCard>
        <LoginHeader>
          <Heading2>Welcome Back</Heading2>
          <Paragraph>Sign in to continue your learning journey</Paragraph>
        </LoginHeader>

        {error && (
          <ErrorMessage initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
            {error}
          </ErrorMessage>
        )}

        <LoginForm onSubmit={handleSubmit}>
          <FormGroup>
            <Input
              type="email"
              name="email"
              label="Email"
              placeholder="Enter your email"
              value={formData.email}
              onChange={handleInputChange}
              required
            />
          </FormGroup>

          <FormGroup>
            <Input
              type="password"
              name="password"
              label="Password"
              placeholder="Enter your password"
              value={formData.password}
              onChange={handleInputChange}
              required
            />
          </FormGroup>

          <ForgotPassword to="/forgot-password">Forgot Password?</ForgotPassword>

          <LoginButton type="submit" disabled={loading}>
            {loading ? "Signing in..." : "Sign In"}
          </LoginButton>
        </LoginForm>

        <LoginFooter>
          <Paragraph>
            Don't have an account? <RegisterLink to="/register">Register here</RegisterLink>
          </Paragraph>
        </LoginFooter>
      </LoginCard>
    </LoginContainer>
  )
}

export default Login

