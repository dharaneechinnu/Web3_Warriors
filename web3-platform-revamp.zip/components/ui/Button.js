import styled, { keyframes } from "styled-components"

const pulse = keyframes`
  0% {
    box-shadow: 0 0 0 0 rgba(124, 58, 237, 0.7);
  }
  70% {
    box-shadow: 0 0 0 10px rgba(124, 58, 237, 0);
  }
  100% {
    box-shadow: 0 0 0 0 rgba(124, 58, 237, 0);
  }
`

const ButtonBase = styled.button`
  position: relative;
  padding: ${(props) => (props.size === "large" ? "0.875rem 1.5rem" : "0.625rem 1.25rem")};
  font-size: ${(props) => (props.size === "large" ? "1.125rem" : "0.875rem")};
  font-weight: 600;
  letter-spacing: 0.025em;
  border-radius: 0.5rem;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  cursor: pointer;
  overflow: hidden;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
  
  &:before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(
      90deg,
      transparent,
      rgba(255, 255, 255, 0.2),
      transparent
    );
    transition: all 0.6s;
  }
  
  &:hover:before {
    left: 100%;
  }
`

const PrimaryButton = styled(ButtonBase)`
  background: linear-gradient(135deg, #7c3aed, #4f46e5);
  color: white;
  border: none;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px -5px rgba(124, 58, 237, 0.5);
  }
  
  &:active {
    transform: translateY(0);
  }
  
  ${(props) =>
    props.pulse &&
    `
    animation: ${pulse} 2s infinite;
  `}
`

const SecondaryButton = styled(ButtonBase)`
  background: transparent;
  color: #7c3aed;
  border: 2px solid #7c3aed;
  
  &:hover {
    background: rgba(124, 58, 237, 0.1);
    transform: translateY(-2px);
  }
  
  &:active {
    transform: translateY(0);
  }
`

const Button = ({ children, variant = "primary", size = "medium", pulse = false, ...props }) => {
  if (variant === "primary") {
    return (
      <PrimaryButton size={size} pulse={pulse} {...props}>
        {children}
      </PrimaryButton>
    )
  }

  return (
    <SecondaryButton size={size} {...props}>
      {children}
    </SecondaryButton>
  )
}

export default Button

