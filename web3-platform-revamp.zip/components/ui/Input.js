"use client"

import React from "react"
import styled from "styled-components"

const InputWrapper = styled.div`
  position: relative;
  width: 100%;
`

const StyledInput = styled.input`
  width: 100%;
  padding: 0.75rem 1rem;
  font-size: 1rem;
  background: rgba(30, 30, 46, 0.6);
  border: 2px solid ${(props) => (props.error ? "#ef4444" : "rgba(124, 58, 237, 0.3)")};
  border-radius: 0.5rem;
  color: white;
  transition: all 0.3s ease;
  
  &:focus {
    outline: none;
    border-color: #7c3aed;
    box-shadow: 0 0 0 3px rgba(124, 58, 237, 0.3);
  }
  
  &::placeholder {
    color: rgba(255, 255, 255, 0.5);
  }
`

const Label = styled.label`
  position: absolute;
  left: 0.75rem;
  top: ${(props) => (props.floating ? "-0.5rem" : "0.75rem")};
  font-size: ${(props) => (props.floating ? "0.75rem" : "1rem")};
  color: ${(props) => (props.floating ? "#7c3aed" : "rgba(255, 255, 255, 0.7)")};
  background: ${(props) => (props.floating ? "rgba(30, 30, 46, 0.8)" : "transparent")};
  padding: ${(props) => (props.floating ? "0 0.25rem" : "0")};
  pointer-events: none;
  transition: all 0.2s ease;
  z-index: 1;
`

const ErrorMessage = styled.p`
  color: #ef4444;
  font-size: 0.75rem;
  margin-top: 0.25rem;
`

const Input = ({ label, error, ...props }) => {
  const [isFocused, setIsFocused] = React.useState(false)
  const [value, setValue] = React.useState(props.value || "")

  const handleFocus = () => setIsFocused(true)
  const handleBlur = () => setIsFocused(false)
  const handleChange = (e) => {
    setValue(e.target.value)
    if (props.onChange) props.onChange(e)
  }

  const isFloating = isFocused || value

  return (
    <InputWrapper>
      {label && <Label floating={isFloating}>{label}</Label>}
      <StyledInput {...props} error={error} onFocus={handleFocus} onBlur={handleBlur} onChange={handleChange} />
      {error && <ErrorMessage>{error}</ErrorMessage>}
    </InputWrapper>
  )
}

export default Input

